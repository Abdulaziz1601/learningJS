// const printRainbow = require('./print');

import { printRainbow } from './print.mjs';

printRainbow('Hello World');