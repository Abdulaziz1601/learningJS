// const colors = require('colors');

import colors from 'colors';

export function printRainbow(string) {
  console.log(`${string}`.rainbow);
}